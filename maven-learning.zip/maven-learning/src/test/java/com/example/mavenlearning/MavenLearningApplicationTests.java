package com.example.mavenlearning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavenLearningApplicationTests {

	@Test
	void contextLoads() {
	}

}
